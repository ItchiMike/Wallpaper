package be.mikael.wallpaper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 42;
    private static final int[] EVERY_VALUES = {15, 30, 60, 180, 720, -1};
    private static final String[] EVERY_LABELS = {"Toutes les 15 min", "Toutes les 30 min", "Toutes les heures",
            "Toutes les 3 h", "Toutes les 12 h", "Personnalisé…"};

    private SharedPreferences prefs;
    private final ExecutorService exec = Executors.newFixedThreadPool(2);
    private String screen = Prefs.INNER;
    private boolean binding;

    private Switch master, touch, unlock, interval, random;
    private Spinner every;
    private EditText custom;
    private LinearLayout thumbs;
    private TextView count, status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = Prefs.get(this);

        master = findViewById(R.id.master);
        touch = findViewById(R.id.touch);
        unlock = findViewById(R.id.unlock);
        interval = findViewById(R.id.interval);
        random = findViewById(R.id.random);
        every = findViewById(R.id.every);
        custom = findViewById(R.id.custom);
        thumbs = findViewById(R.id.thumbs);
        count = findViewById(R.id.count);
        status = findViewById(R.id.status);

        // Ouvre par défaut sur l'écran utilisé (déplié = interne, plié = externe)
        screen = isUnfolded() ? Prefs.INNER : Prefs.OUTER;
        RadioGroup group = findViewById(R.id.screens);
        group.check(Prefs.INNER.equals(screen) ? R.id.screen_inner : R.id.screen_outer);
        group.setOnCheckedChangeListener((g, id) -> {
            screen = id == R.id.screen_inner ? Prefs.INNER : Prefs.OUTER;
            bind();
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, EVERY_LABELS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        every.setAdapter(adapter);
        every.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (binding) return;
                int v = EVERY_VALUES[pos];
                custom.setVisibility(v < 0 ? View.VISIBLE : View.GONE);
                if (v > 0) saveEvery(v);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        custom.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override
            public void afterTextChanged(Editable e) {
                if (binding) return;
                try {
                    int v = Integer.parseInt(e.toString().trim());
                    if (v >= 1) saveEvery(v);
                } catch (NumberFormatException ignored) {}
            }
        });

        master.setOnCheckedChangeListener((b, on) -> {
            if (!binding) prefs.edit().putBoolean(Prefs.MASTER, on).apply();
        });
        hook(touch, Prefs.TOUCH);
        hook(unlock, Prefs.UNLOCK);
        hook(interval, Prefs.INTERVAL);
        hook(random, Prefs.RANDOM);

        Button add = findViewById(R.id.add);
        add.setOnClickListener(v -> pickImages());
        Button clear = findViewById(R.id.clear);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage(R.string.clear_q)
                .setPositiveButton(R.string.yes, (d, w) -> {
                    for (String u : Prefs.uris(prefs, screen)) releaseIfUnused(u, true);
                    Prefs.setUris(prefs, screen, new java.util.ArrayList<>());
                    bind();
                })
                .setNegativeButton(R.string.cancel, null)
                .show());

        Button next = findViewById(R.id.next);
        next.setOnClickListener(v -> {
            if (!Prefs.next(prefs, screen)) {
                Toast.makeText(this, R.string.no_images, Toast.LENGTH_SHORT).show();
            }
            renderThumbs();
        });

        Button apply = findViewById(R.id.apply);
        apply.setOnClickListener(v -> applyWallpaper());

        bind();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdownNow();
    }

    private boolean isUnfolded() {
        Configuration c = getResources().getConfiguration();
        int w = c.screenWidthDp, h = c.screenHeightDp;
        if (w <= 0 || h <= 0) return true;
        return (float) Math.min(w, h) / Math.max(w, h) > 0.65f;
    }

    private void hook(Switch sw, String name) {
        sw.setOnCheckedChangeListener((CompoundButton b, boolean on) -> {
            if (binding) return;
            prefs.edit().putBoolean(Prefs.key(name, screen), on).apply();
            if (Prefs.INTERVAL.equals(name)) {
                // repart de zéro pour ne pas changer immédiatement
                prefs.edit().putLong(Prefs.key(Prefs.LAST, screen), System.currentTimeMillis()).apply();
                every.setEnabled(on);
                custom.setEnabled(on);
            }
        });
    }

    private void saveEvery(int minutes) {
        if (prefs.getInt(Prefs.key(Prefs.EVERY, screen), 60) == minutes) return;
        prefs.edit()
                .putInt(Prefs.key(Prefs.EVERY, screen), minutes)
                .putLong(Prefs.key(Prefs.LAST, screen), System.currentTimeMillis())
                .apply();
    }

    /** Remplit l'écran avec les réglages de l'écran sélectionné. */
    private void bind() {
        binding = true;
        master.setChecked(Prefs.master(prefs));
        touch.setChecked(Prefs.bool(prefs, Prefs.TOUCH, screen));
        unlock.setChecked(Prefs.bool(prefs, Prefs.UNLOCK, screen));
        interval.setChecked(Prefs.bool(prefs, Prefs.INTERVAL, screen));
        random.setChecked(Prefs.bool(prefs, Prefs.RANDOM, screen));
        int minutes = Prefs.everyMinutes(prefs, screen);
        int pos = EVERY_VALUES.length - 1;
        for (int i = 0; i < EVERY_VALUES.length; i++) {
            if (EVERY_VALUES[i] == minutes) { pos = i; break; }
        }
        every.setSelection(pos, false);
        boolean isCustom = EVERY_VALUES[pos] < 0;
        custom.setVisibility(isCustom ? View.VISIBLE : View.GONE);
        custom.setText(isCustom ? String.valueOf(minutes) : "");
        every.setEnabled(interval.isChecked());
        custom.setEnabled(interval.isChecked());
        binding = false;
        renderThumbs();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void renderThumbs() {
        thumbs.removeAllViews();
        final List<String> list = Prefs.uris(prefs, screen);
        int current = Prefs.index(prefs, screen, list.size());
        count.setText(getString(R.string.images) + " – " + list.size());
        int w = dp(76);
        int h = Prefs.INNER.equals(screen) ? dp(84) : dp(150);
        int accent = getColor(R.color.accent);
        for (int i = 0; i < list.size(); i++) {
            final String u = list.get(i);
            final ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
            lp.setMarginEnd(dp(8));
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setContentDescription("Image " + (i + 1));
            if (i == current) {
                iv.setBackgroundColor(accent);
                iv.setPadding(dp(3), dp(3), dp(3), dp(3));
            } else {
                iv.setBackgroundColor(0xFF2A2E36);
            }
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this)
                        .setMessage(R.string.remove_q)
                        .setPositiveButton(R.string.yes, (d, which) -> {
                            List<String> l = Prefs.uris(prefs, screen);
                            l.remove(u);
                            Prefs.setUris(prefs, screen, l);
                            releaseIfUnused(u, false);
                            renderThumbs();
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return true;
            });
            thumbs.addView(iv);
            exec.execute(() -> {
                try {
                    Bitmap b = Bitmaps.decode(this, Uri.parse(u), 200, 200);
                    runOnUiThread(() -> iv.setImageBitmap(b));
                } catch (Exception | OutOfMemoryError ignored) {}
            });
        }
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return;
        List<String> list = Prefs.uris(prefs, screen);
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) addUri(clip.getItemAt(i).getUri(), list);
        } else if (data.getData() != null) {
            addUri(data.getData(), list);
        }
        Prefs.setUris(prefs, screen, list);
        renderThumbs();
    }

    private void addUri(Uri uri, List<String> list) {
        if (uri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {}
        String s = uri.toString();
        if (!list.contains(s)) list.add(s);
    }

    /** Libère l'accès à une image si l'autre écran ne l'utilise pas. */
    private void releaseIfUnused(String u, boolean clearingAll) {
        String other = Prefs.INNER.equals(screen) ? Prefs.OUTER : Prefs.INNER;
        if (Prefs.uris(prefs, other).contains(u)) return;
        try {
            getContentResolver().releasePersistableUriPermission(Uri.parse(u), Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
    }

    private void applyWallpaper() {
        Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, RotatingWallpaperService.class));
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (Exception ignored) {
                Toast.makeText(this, "Impossible d'ouvrir le sélecteur de fond d'écran", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void updateStatus() {
        WallpaperInfo info = WallpaperManager.getInstance(this).getWallpaperInfo();
        boolean active = info != null && getPackageName().equals(info.getPackageName());
        status.setText(active ? R.string.status_on : R.string.status_off);
    }
}
