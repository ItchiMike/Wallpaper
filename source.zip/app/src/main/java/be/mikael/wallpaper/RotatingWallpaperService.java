package be.mikael.wallpaper;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fond d'écran animé qui affiche une image choisie par l'utilisateur.
 * Sur le Fold, l'écran interne est presque carré et l'écran externe est étroit :
 * le format de la surface indique donc sur quel écran on se trouve.
 */
public class RotatingWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new RotEngine();
    }

    private class RotEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final ExecutorService exec = Executors.newSingleThreadExecutor();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private SharedPreferences prefs;

        private int width, height;
        private boolean visible;

        private Bitmap bitmap;
        private String shownUri, shownScreen;
        private int loadedW, loadedH;

        private long lastTapTime;
        private float lastTapX, lastTapY;

        private final Runnable tick = this::checkInterval;
        private final Runnable reload = () -> {
            loadAndDraw();
            if (visible) checkInterval();
        };

        private final BroadcastReceiver unlockReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (!Intent.ACTION_USER_PRESENT.equals(intent.getAction()) || isPreview()) return;
                String s = screen();
                if (s != null && Prefs.master(prefs) && Prefs.bool(prefs, Prefs.UNLOCK, s)) {
                    Prefs.next(prefs, s);
                }
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = Prefs.get(RotatingWallpaperService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            setTouchEventsEnabled(true);
            IntentFilter f = new IntentFilter(Intent.ACTION_USER_PRESENT);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(unlockReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(unlockReceiver, f);
            }
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.removeCallbacksAndMessages(null);
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            try { unregisterReceiver(unlockReceiver); } catch (IllegalArgumentException ignored) {}
            exec.shutdownNow();
        }

        /** "interne" si la surface est presque carrée, "externe" si elle est étroite. */
        private String screen() {
            if (width <= 0 || height <= 0) return null;
            float ratio = (float) Math.min(width, height) / Math.max(width, height);
            return ratio > 0.65f ? Prefs.INNER : Prefs.OUTER;
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            loadAndDraw();
            if (visible) checkInterval();
        }

        @Override
        public void onSurfaceRedrawNeeded(SurfaceHolder holder) {
            super.onSurfaceRedrawNeeded(holder);
            draw();
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) {
                loadAndDraw();
                checkInterval();   // rattrape un changement "dû" pendant que l'écran était éteint
            } else {
                handler.removeCallbacks(tick);
            }
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            handler.removeCallbacks(reload);
            handler.postDelayed(reload, 150);
        }

        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (!isPreview()) Prefs.logEvent(RotatingWallpaperService.this, "cmd:" + action);
            if (WallpaperManager.COMMAND_TAP.equals(action)) onTap(x, y);
            return null;
        }

        @Override
        public void onTouchEvent(MotionEvent e) {
            // Certains lanceurs ne passent pas par COMMAND_TAP : on regarde aussi les touches directes.
            if (isPreview() || e.getActionMasked() != MotionEvent.ACTION_UP) return;
            Prefs.logEvent(RotatingWallpaperService.this, "touch");
            onTap(e.getX(), e.getY());
        }

        private void onTap(float x, float y) {
            String s = screen();
            if (s == null || !Prefs.master(prefs) || !Prefs.bool(prefs, Prefs.TOUCH, s)) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastTapTime < 120 && Math.hypot(x - lastTapX, y - lastTapY) < 20) return; // même appui reçu deux fois
            if (Prefs.bool(prefs, Prefs.SINGLE_TAP, s)) {
                lastTapTime = now; lastTapX = x; lastTapY = y;
                Prefs.next(prefs, s);
                return;
            }
            boolean isDouble = now - lastTapTime < 600 && Math.hypot(x - lastTapX, y - lastTapY) < 300;
            if (isDouble) {
                lastTapTime = 0;
                Prefs.logEvent(RotatingWallpaperService.this, "double");
                Prefs.next(prefs, s);
            } else {
                lastTapTime = now;
                lastTapX = x;
                lastTapY = y;
            }
        }

        private void checkInterval() {
            handler.removeCallbacks(tick);
            String s = screen();
            if (s == null || isPreview() || !Prefs.master(prefs) || !Prefs.bool(prefs, Prefs.INTERVAL, s)) return;
            long every = Prefs.everyMinutes(prefs, s) * 60_000L;
            long last = prefs.getLong(Prefs.key(Prefs.LAST, s), 0L);
            long now = System.currentTimeMillis();
            long due = last + every;
            if (now >= due) {
                if (!Prefs.next(prefs, s)) return; // le listener redessine et replanifie
            } else if (visible) {
                handler.postDelayed(tick, due - now);
            }
        }

        private void loadAndDraw() {
            final String s = screen();
            if (s == null) return;
            final String uri = Prefs.current(prefs, s);
            if (uri == null) {
                bitmap = null;
                shownUri = null;
                shownScreen = s;
                draw();
                return;
            }
            if (uri.equals(shownUri) && s.equals(shownScreen) && bitmap != null
                    && loadedW == width && loadedH == height) {
                draw();
                return;
            }
            final int w = width, h = height;
            exec.execute(() -> {
                Bitmap b = null;
                try {
                    b = Bitmaps.decode(RotatingWallpaperService.this, Uri.parse(uri), w, h);
                } catch (Exception | OutOfMemoryError ignored) {
                }
                final Bitmap result = b;
                handler.post(() -> {
                    bitmap = result;
                    shownUri = uri;
                    shownScreen = s;
                    loadedW = w;
                    loadedH = h;
                    draw();
                });
            });
        }

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockHardwareCanvas();
                if (c == null) return;
                int cw = c.getWidth(), ch = c.getHeight();
                c.drawColor(Color.rgb(15, 17, 21));
                if (bitmap != null) {
                    float scale = Math.max((float) cw / bitmap.getWidth(), (float) ch / bitmap.getHeight());
                    float dw = bitmap.getWidth() * scale, dh = bitmap.getHeight() * scale;
                    float left = (cw - dw) / 2f, top = (ch - dh) / 2f;
                    c.drawBitmap(bitmap, null, new RectF(left, top, left + dw, top + dh), paint);
                } else {
                    TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                    tp.setColor(Color.rgb(201, 206, 214));
                    tp.setTextSize(cw / 20f);
                    int boxW = (int) (cw * 0.8f);
                    StaticLayout layout = StaticLayout.Builder
                            .obtain(getString(R.string.empty_wallpaper), 0,
                                    getString(R.string.empty_wallpaper).length(), tp, boxW)
                            .setAlignment(Layout.Alignment.ALIGN_CENTER)
                            .build();
                    c.save();
                    c.translate((cw - boxW) / 2f, (ch - layout.getHeight()) / 2f);
                    layout.draw(c);
                    c.restore();
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) {}
                }
            }
        }
    }
}
