package be.mikael.wallpaper;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Widget 1x1 « Changer » : passe à l'image suivante de l'écran utilisé. */
public class ChangeWidget extends AppWidgetProvider {
    static final String ACTION_CHANGE = "be.mikael.wallpaper.CHANGE";

    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        Intent i = new Intent(c, ChangeWidget.class).setAction(ACTION_CHANGE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_change);
            v.setOnClickPendingIntent(R.id.widget_root, pi);
            mgr.updateAppWidget(id, v);
        }
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_CHANGE.equals(intent.getAction())) {
            Prefs.logEvent(c, "widget");
            Prefs.next(Prefs.get(c), Prefs.screenNow(c));
        }
    }
}
