package be.mikael.wallpaper;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Tuile des réglages rapides « Changer le fond ». */
public class ChangeTileService extends TileService {
    @Override
    public void onStartListening() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(Tile.STATE_ACTIVE);
        t.updateTile();
    }

    @Override
    public void onClick() {
        Prefs.logEvent(this, "tile");
        Prefs.next(Prefs.get(this), Prefs.screenNow(this));
    }
}
