package be.mikael.wallpaper;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Tuile des réglages rapides « Changer le fond ». */
public class ChangeTileService extends TileService {
    @Override
    public void onStartListening() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(Tile.STATE_ACTIVE);
        t.updateTile();
    }

    @Override
    public void onClick() {
        Prefs.logEvent(this, "tile");
        String s = Prefs.screenNow(this);
        android.app.KeyguardManager km = getSystemService(android.app.KeyguardManager.class);
        boolean locked = km != null && km.isKeyguardLocked();
        android.content.SharedPreferences p = Prefs.get(this);
        if (locked && !Prefs.uris(p, Prefs.lockOf(s)).isEmpty()) {
            Prefs.next(p, Prefs.lockOf(s));
            if (Prefs.lockStatic(p)) {
                final android.content.Context app = getApplicationContext();
                new Thread(() -> LockSetter.apply(app, s)).start();
            }
        } else {
            Prefs.next(p, s);
        }
    }
}
