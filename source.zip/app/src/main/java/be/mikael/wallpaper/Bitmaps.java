package be.mikael.wallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.util.Size;

import java.io.IOException;

/** Décodage d'images à la bonne taille (gère aussi la rotation EXIF des photos). */
final class Bitmaps {
    private Bitmaps() {}

    static Bitmap decode(Context c, Uri uri, int reqW, int reqH) throws IOException {
        ImageDecoder.Source src = ImageDecoder.createSource(c.getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(src, (decoder, info, source) -> {
            Size s = info.getSize();
            int sample = 1;
            if (reqW > 0 && reqH > 0) {
                sample = Math.max(1, Math.min(s.getWidth() / reqW, s.getHeight() / reqH));
            }
            decoder.setTargetSampleSize(sample);
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
    }
}
