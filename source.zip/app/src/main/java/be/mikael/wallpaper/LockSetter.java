package be.mikael.wallpaper;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.DisplayMetrics;

/**
 * Mode compatibilité : pose une image fixe sur l'écran de verrouillage
 * (au cas où One UI n'affiche pas le fond animé quand le téléphone est verrouillé).
 * À appeler hors du fil principal.
 */
final class LockSetter {
    private static String lastSet;

    private LockSetter() {}

    static synchronized void apply(Context c, String screen) {
        SharedPreferences p = Prefs.get(c);
        if (!Prefs.lockStatic(p)) return;
        String uri = Prefs.lockImage(p, screen);
        if (uri == null || uri.equals(lastSet)) return;
        try {
            DisplayMetrics m = c.getResources().getDisplayMetrics();
            android.graphics.Bitmap b = Bitmaps.decode(c, Uri.parse(uri), m.widthPixels, m.heightPixels);
            WallpaperManager.getInstance(c).setBitmap(b, null, true, WallpaperManager.FLAG_LOCK);
            lastSet = uri;
            Prefs.logEvent(c, "lock_static");
        } catch (Exception | OutOfMemoryError e) {
            Prefs.logEvent(c, "lock_static_erreur");
        }
    }
}
