package be.mikael.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Réglages, séparés pour chaque écran ("interne" / "externe"). */
final class Prefs {
    static final String INNER = "interne";
    static final String OUTER = "externe";

    static final String MASTER = "master";
    static final String URIS = "uris";
    static final String INDEX = "idx";
    static final String LAST = "last";
    static final String TOUCH = "touch";
    static final String UNLOCK = "unlock";
    static final String INTERVAL = "interval";
    static final String EVERY = "every";      // minutes
    static final String RANDOM = "random";

    private static final Random RNG = new Random();

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("wallpapers", Context.MODE_PRIVATE);
    }

    static String key(String name, String screen) {
        return name + "_" + screen;
    }

    static boolean master(SharedPreferences p) {
        return p.getBoolean(MASTER, true);
    }

    static boolean bool(SharedPreferences p, String name, String screen) {
        boolean def;
        switch (name) {
            case UNLOCK: def = false; break;
            default: def = true; // TOUCH, INTERVAL, RANDOM
        }
        return p.getBoolean(key(name, screen), def);
    }

    static int everyMinutes(SharedPreferences p, String screen) {
        return Math.max(1, p.getInt(key(EVERY, screen), 60));
    }

    static List<String> uris(SharedPreferences p, String screen) {
        String raw = p.getString(key(URIS, screen), "");
        List<String> out = new ArrayList<>();
        for (String s : raw.split("\n")) {
            if (!s.trim().isEmpty()) out.add(s.trim());
        }
        return out;
    }

    static void setUris(SharedPreferences p, String screen, List<String> list) {
        p.edit().putString(key(URIS, screen), String.join("\n", list)).apply();
    }

    static int index(SharedPreferences p, String screen, int size) {
        if (size <= 0) return -1;
        int i = p.getInt(key(INDEX, screen), 0);
        return (i < 0 || i >= size) ? 0 : i;
    }

    /** Image affichée actuellement pour cet écran (ou null si aucune). */
    static String current(SharedPreferences p, String screen) {
        List<String> l = uris(p, screen);
        int i = index(p, screen, l.size());
        return i < 0 ? null : l.get(i);
    }

    /** Passe à l'image suivante. Retourne false s'il n'y a pas d'image. */
    static boolean next(SharedPreferences p, String screen) {
        List<String> l = uris(p, screen);
        if (l.isEmpty()) return false;
        int cur = index(p, screen, l.size());
        int nxt;
        if (l.size() == 1) {
            nxt = 0;
        } else if (bool(p, RANDOM, screen)) {
            nxt = RNG.nextInt(l.size() - 1);
            if (nxt >= cur) nxt++;           // jamais deux fois la même d'affilée
        } else {
            nxt = (cur + 1) % l.size();
        }
        p.edit()
                .putInt(key(INDEX, screen), nxt)
                .putLong(key(LAST, screen), System.currentTimeMillis())
                .apply();
        return true;
    }
}
